# A3D V4 Material Studio Template

This template starts a material review workflow from the public `@aura3d/engine` package.

```sh
npm install
npm run dev
```

It uses `createA3DApp`, `workflows.materialStudio`, `createEnvironment`, and `createDiagnosticsPanel`. It does not import workspace source files or test helpers.
