import { runV6Example } from "@aura3d/engine/workflows/production";

void runV6Example({
  appId: "production-runtime-template-material-studio",
  sceneId: "material-studio",
  title: "V6 Material Studio",
  workflow: "starter material workflow for glTF extension assets with HDR lighting and postprocess",
  assets: [
    { id: "clear-coat-test", label: "Clear Coat Test", file: "clear-coat-test.glb", role: "primary" },
    { id: "sheen-test-grid", label: "Sheen Test Grid", file: "sheen-test-grid.glb", role: "secondary" }
  ],
  environment: { id: "studio-small-08", label: "Studio Small 08", file: "studio_small_08_1k.hdr", exposure: 1, intensity: 1.15, rotation: 0.15 },
  postprocess: true,
  webgpuReport: false,
  expectedPostprocessChain: ["tone-mapping", "color-grade", "bloom", "fxaa"]
});
